"""
Default Fallback Intent
"""

import re


def fallback(
        df_request,
        df_response):
    """
    fallback
    """

    if re.search('((say( that)? )?again|repeat( that)?)( please)?',
                 df_request.query_text):

        # repeat

        # Trigger the confirmYes event.
        df_response.event_to_trigger = 'repeat'
