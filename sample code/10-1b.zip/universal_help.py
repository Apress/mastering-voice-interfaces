"""
help universal
"""

from utils import processed_intent_name


def universal_help(df_request, df_response):
    """
    help universal
    """

    most_recent_intent_name = df_request.most_recent_intent.get("name")

    print(most_recent_intent_name)
    if (most_recent_intent_name ==
        processed_intent_name('Default Welcome Intent') or
        most_recent_intent_name == processed_intent_name('mainMenu')):
        df_response.output_text = \
            ("Here's some help. This is the procedure helper."
             "You can asks things like \"What should I do today?\" or"
             "\"Can I eat rice today?\". Now go ahead.")
    elif most_recent_intent_name == processed_intent_name('arTodaysTasks'):
        df_response.output_text = \
            ("Here\'s some help. These are the tasks that are on your care"
             "calendar to do today. Say repeat to hear them again.")
    else:
        df_response.output_text = "Sorry, help is not enabled here."
