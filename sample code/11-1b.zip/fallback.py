"""
Default Fallback Intent
"""

import re

from spacy_parser import dependency_parse

def fallback(
        df_request,
        df_response):
    """
    fallback
    """

    if re.search('((say( that)? )?again|repeat( that)?)( please)?',
                 df_request.query_text):

        # repeat

        # Trigger the confirmYes event.
        df_response.event_to_trigger = 'repeat'
    else:
        # We didn't get a hit with regular expressions; try dependency parse.

        parse = dependency_parse(df_request.query_text)

        # Collect features from the dependency parse tree

        # Get the root node in the dependency parse tree
        root_verb_index = None
        root_verb_lemma = None
        for node in parse:
            if node.get('relation') == 'ROOT':
                root_verb_index = node.get('index')
                root_verb_lemma = node.get('lemma')

        # Get a dobj off the root node
        dobj_lemma = None
        for node in parse:
            if (node.get('relation') == 'dobj' and
                node.get('parent_index') == root_verb_index):
                dobj_lemma = node.get('lemma')

        if root_verb_lemma == 'do' and dobj_lemma == 'what':
            # "What should I do today?."

            # Trigger arTodaysTasks
            df_response.event_to_trigger = 'arTodaysTasks'
        else:
            # No dependency parse match; do what Dialogflow would have done

            df_response.output_text = df_request.fulfillment_text
