"""
Set the most recent intent.
"""

import re

from utils import is_skippable_universal


def set_most_recent_intent(df_request, intent_name, context):
    """
    See if this is the most recent intent.
    """
    match2 = re.search('^intent_(.*)$', intent_name)
    if match2:
        if 'parameters' in context:
            if 'timestamp' in context['parameters']:
                context_time = context['parameters']['timestamp']
                if (context_time > df_request.most_recent_intent.get('time') and
                    not is_skippable_universal(match2.group(1))):
                    df_request.most_recent_intent["name"] = match2.group(1)
                    df_request.most_recent_intent["time"] = context_time
