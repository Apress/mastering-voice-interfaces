"""
repeat universal
"""


def universal_repeat(df_request, df_response):
    """
    repeat universal
    """

    most_recent_intent_name = df_request.most_recent_intent.get("name")
    if most_recent_intent_name == 'arTodaysTasks'.lower():
        df_response.output_text = \
            ("Sure. Again: You have two things to do today. First, you need "
             "to make sure you can get a ride home after the procedure. "
             "Second, you need to get the laxative.")
    else:
        df_response.output_text = "Sorry, repeat is not enabled here."
