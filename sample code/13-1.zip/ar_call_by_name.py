"""
Call by name.
Here are the list of names:

Brent Jones
Brent Adams
Brent Barnes
Brent Carletti
Joe Jones
Kim Smith
Mary Poppins
"""

from confirmation_context import confirmation_context


def ar_call_by_name(df_request, df_response):
    """
    Call by name.
    """

    given_name = df_request.parameters.get('given-name')
    last_name = df_request.parameters.get('last-name')

    if (given_name and not given_name == '' and
        last_name and not last_name == ''):

        # If the caller specified both the first name and the
        # last name (“Call Brent Jones”), we don’t need disambiguation,
        # just do that. This is the “do what you were going to do case,”
        # where the webhook does not modify what Dialogflow was going to
        # do anyway.

        if df_response.explicit_confirmation:
            df_response.output_text = \
                f"You want to call {given_name} {last_name}, right?"
            df_response.output_contexts.append(
                confirmation_context(given_name,
                                     last_name))
        else:
            df_response.output_text = df_request.fulfillment_text
            df_response.end_conversation = True
            df_response.nva["do"] = True
    elif (given_name and not given_name == ''):

        # This section of the code is very specific to the name list
        # that we’ve set up. Later on we can make it more generic, and
        # hit databases and such.

        # If the caller only specified a first name

        if given_name == 'Brent':

            # If you need to disambiguate last name (e.g., “Call Brent”)

            # Change the response to ask the “Which Brent...” question.

            df_response.output_text = \
                'Which Brent: Jones, Adams, Barnes, or Carletti?'

            # Add the output context callbyname.
            # Remember when you created arCallByNameDisambigLastName,
            # you added that as an input context, and might have
            # wondered where you set it? Here’s where that is.

            new_context = {
                'name': ('projects/${PROJECT_ID}/agent/sessions'
                         '/${SESSION_ID}/contexts/callbyname'),
                'lifespanCount': 5,
                'parameters': {}
            }
            # The full context name is long; "callbyname" is only the
            # last part.

            # Add a parameter context-given-name to the callbyname
            # context. You can add parameters to contexts, and you’ll
            # see in a bit how useful that is.

            new_context['parameters']['context-given-name'] = given_name

            df_response.output_contexts.append(new_context)

        else:

            # If you don’t need to disambiguate, there’s only one name
            # (e.g., “Call Mary”), find the last name, and respond with
            # that. No need to ask. Remember, don’t disambiguate unless
            # you need to!

            if given_name == 'Kim':
                if df_response.explicit_confirmation:
                    df_response.output_text = \
                        "You want to call Kim Smith, right?"
                    df_response.output_contexts.append(
                        confirmation_context("Kim", "Smith"))
                else:
                    df_response.output_text = 'OK, calling Kim Smith.'
                    df_response.end_conversation = True
                    df_response.nva["do"] = True
            elif given_name == 'Mary':
                if df_response.explicit_confirmation:
                    df_response.output_text = \
                        "You want to call Mary Poppins, right?"
                    df_response.output_contexts.append(
                        confirmation_context("Mary", "Poppins"))
                else:
                    df_response.output_text = 'OK, calling Mary Poppins.'
                    df_response.end_conversation = True
                    df_response.nva["do"] = True
            else:

                # If you don’t have that first name (e.g., “Call Donald”),
                # play a response that says so.

                df_response.output_text = \
                    f"Sorry, there is no {given_name} in your list."
                df_response.end_conversation = True
