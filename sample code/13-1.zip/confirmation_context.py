"""
confirmation_context() produces a context for name confirmation.
"""

def confirmation_context(first, last):
    """
    Returns name confirmation context.
    """

    new_context = {}

    # The full context name is long; "callbyname" is only the last part.
    new_context['name'] = \
        ('projects/${PROJECT_ID}/agent/sessions/${SESSION_ID}/'
         'contexts/confirmName')
    new_context['lifespanCount'] = 5

    # Add first and last names as parameters to the context.
    # You can add parameters to contexts, and you’ll see in a bit how
    # useful that is.

    new_context['parameters'] = {}
    new_context['parameters']['given-name'] = first
    new_context['parameters']['last-name'] = last

    return new_context
