"""
Handling for date of birth, with one step correction.
"""

from new_context import new_context


def dob(df_request, df_response):
    """
    Date of birth
    """
    # Set the confirmDOB context with date parameters.

    context = new_context('confirmdob')

    # Add month, day, year parameters to the output context
    # so we have them for later.

    if 'month' in df_request.parameters:
        context['parameters']['currentmonth'] = df_request.parameters['month']

    if 'day' in df_request.parameters:
        context['parameters']['currentday'] = df_request.parameters['day']

    if 'year' in df_request.parameters:
        context['parameters']['currentyear'] = df_request.parameters['year']

    # Append the new context
    df_response.output_contexts.append(context)

    # Use the response in Dialogflow
    df_response.output_text = df_request.fulfillment_text
