"""
Creates a new output context.
"""

import time

def new_context(name):
    """
    Return a new output context with a given name.
    """

    context = {
        'name': ("projects/${PROJECT_ID}/agent/sessions/"
                 f"${{SESSION_ID}}/contexts/{name}"),
        'lifespanCount': 5,
        'parameters': {
            'timestamp': time.time()
        }
    }

    return context
