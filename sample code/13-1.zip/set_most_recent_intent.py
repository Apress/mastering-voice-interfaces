"""
Set the most recent intent.
"""

import re

from utils import is_skippable_universal


def set_most_recent_intent(df_request, intent_name, context):
    """
    Set the most recent intent.
    """
    match2 = re.search('^intent_(.*)$', intent_name)
    if match2:
        if 'parameters' in context:
            if 'timestamp' in context['parameters']:
                context_time = context['parameters']['timestamp']

                # Set the last intent, including universals and fallback
                if context_time > df_request.most_recent_intent['time_all']:
                    df_request.most_recent_intent["name_all"] = match2.group(1)
                    df_request.most_recent_intent["time_all"] = context_time

                # Set the last non-skippable intent: no universals or fallback
                if (context_time > df_request.most_recent_intent['time'] and
                    not is_skippable_universal(match2.group(1))):
                    df_request.most_recent_intent["name"] = match2.group(1)
                    df_request.most_recent_intent["time"] = context_time

                # Set the last non-fallback intent, for escalating prompts.
                if (context_time >
                    df_request.most_recent_intent['time_non_fallback'] and
                    not match2.group(1) == 'default_fallback_intent'):
                    df_request.most_recent_intent["name_non_fallback"] = \
                        match2.group(1)
                    df_request.most_recent_intent["time_non_fallback"] = \
                        context_time
