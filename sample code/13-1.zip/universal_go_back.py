"""
go back universal
"""


def universal_go_back(
        df_request,     # pylint: disable=unused-argument
        df_response):
    """
    go back universal
    """

    df_response.output_text = 'Sorry, go back is not enabled here.'
