"""
The webhook_request module contains the WebhookRequest class
for the Dialogflow request.
"""

import json
import re

from set_most_recent_intent import set_most_recent_intent

class WebhookRequest():
    """
    The WebhookRequest class contains the information from the
    Dialogflow webhook request.
    """

    def __init__(self):
        """
        Initialize the WebhookRequest with variables that could be loaded.
        """

        # Here is the various information pulled out of the webhook request.

        # The intent that was triggered
        self.intent_display_name = ''

        # The text that was spoken
        self.query_text = None

        # How Dialogflow was going to respond
        self.fulfillment_text = ''

        # The contexts that were going to be set
        self.input_contexts = {"contexts": [], "names": []}

        # Parameters that were supplied, either from the user speech/text or
        # from contexts.
        self.parameters = []

        # The Dialogflow session
        self.session = None

        # The most recent intent.

        # name/time are for excluding universals.
        # name_all/time_all are for all intents, including universals.
        # name_non_fallback/time_non_fallback are excluding fallback.
        # Need that for notion of dialog state for universals.
        self.most_recent_intent = {
            "name": None,
            "time": 0,
            "name_all": None,
            "time_all": 0,
            "name_non_fallback": None,
            "time_non_fallback": 0}


    def load_from_json(self, request_json):
        """
        Load the WebhookRequest from a JSON dictionary.
        """

        # The unique request/response and session identifiers
        self.session = request_json['session']

        # The full session name is a long string; here we’re just pulling out
        # the tail, or the part after the last /.

        match = re.search('/([^/]*)$', self.session)
        if match:
            self.session = match.group(1)

        query_result = request_json.get("queryResult")
        if query_result:
            self.query_text = query_result.get("queryText", "")
            intent = query_result.get("intent")
            if intent:
                self.intent_display_name = intent.get("displayName")
            self.fulfillment_text = query_result.get("fulfillmentText")
            # These are called ‘outputContexts’ but they really are the inputs
            # in the Dialogflow request.
            self.input_contexts['contexts'] = query_result.get("outputContexts")
            if self.input_contexts["contexts"]:
                for dic in self.input_contexts["contexts"]:
                    fullname = dic.get("name")
                    if fullname:
                        # Same as session; the full context name is long, and
                        # we’re using regular expressions to pull out only the
                        # part after the last /.
                        match = re.search('/([^/]*)$', fullname)
                        if match:
                            self.input_contexts["names"].append(match.group(1))

                            # If this is the most recent intent, set that.
                            set_most_recent_intent(self, match.group(1), dic)
            self.parameters = query_result.get("parameters")
            # Go through the parameters, and turn any list into a singleton
            for param in self.parameters:
                if isinstance(self.parameters[param], list):
                    self.parameters[param] = self.parameters[param][0]

    def load_from_string(self, string):
        """
        Load from string, which we get from the Dialogflow request.
        """

        self.load_from_json(json.loads(string))
