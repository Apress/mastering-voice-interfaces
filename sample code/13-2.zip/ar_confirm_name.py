"""
Dialogflow intent for when are explicitly confirming a name to be called.
"""

from new_context import new_context


def ar_confirm_name(df_request, df_response):
    """
    Result of an explicit name confirmation
    """

    if 'confirm' in df_request.parameters:
        if df_request.parameters['confirm'] == 'yes':
            # The caller has confirmed the name. Play it.

            df_response.output_text = 'OK, calling.'
            df_response.end_conversation = True
            df_response.nva["do"] = True

        elif df_request.parameters['confirm'] == 'no':
            # Negative confirmation

            df_response.output_text = 'Who\'d you like to call?'
            df_response.output_contexts.append(new_context('collectName'))
