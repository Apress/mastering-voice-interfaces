"""
Creates a new output context.
"""

import re
import time

def new_context(name):
    """
    Return a new output context with a given name.
    """

    time_now = time.time()
    lifespan_count = 5

    # If it's an intent context, add the timestamp.
    if name.startswith('intent'):
        name = re.sub('^intent_','intent_%s_' % int(time_now),name)
        lifespan_count = 50

    # The full context name is long; "callbyname" is only the last part.
    context = {
        'name': ("projects/${PROJECT_ID}/agent/sessions/"
                 f"${{SESSION_ID}}/contexts/{name}"),
        'lifespanCount': lifespan_count,
        # Add the time so we can find the most recent context
        'parameters': {
            'timestamp': time_now
        }
    }
    return context
