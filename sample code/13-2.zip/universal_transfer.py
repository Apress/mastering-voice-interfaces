"""
transfer universal
"""


def universal_transfer(
        df_request,     # pylint: disable=unused-argument
        df_response):
    """
    transfer universal
    """

    df_response.output_text = 'Sorry, transferring is not enabled here.'
