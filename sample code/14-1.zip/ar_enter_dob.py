"""
Handling for arEnterDOB
"""

def ar_enter_dob_escalating_nomatch(df_request,        # pylint: disable=unused-argument
                                    df_response):
    """
    Escalating nomatch prompt for arEnterDOB
    """

    df_response.output_text = ('Sorry, I still didn\'t understand. '
                               'Please give your date of birth as '
                               'month, day and year. For example, say, '
                               'March third, 2001.')
