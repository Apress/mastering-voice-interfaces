"""
cancel universal
"""


def universal_cancel(
        df_request,     # pylint: disable=unused-argument
        df_response):
    """
    cancel universal
    """

    df_response.output_text = 'Sorry, cancel is not enabled here.'
