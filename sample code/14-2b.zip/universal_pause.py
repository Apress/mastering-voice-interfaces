"""
pause universal
"""


def universal_pause(
        df_request,     # pylint: disable=unused-argument
        df_response):
    """
    pause universal
    """

    df_response.output_text  = "Sorry, pause is not enabled here."
