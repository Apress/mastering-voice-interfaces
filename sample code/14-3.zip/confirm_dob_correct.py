"""
One-step correction for DOB.
"""


def confirmation_month(df_request, params):
    """
    Month to confirm
    Get from parameters, then context.
    """

    month = None

    if (('month' in df_request.parameters) and
        (df_request.parameters['month'] != '')):
        month = df_request.parameters['month']
    elif (params is not None) and ('currentmonth' in params):
        month = params['currentmonth']

    return month

def confirmation_day(df_request, params):
    """
    Day to confirm

    dayoryear hits this if < 50, e.g., "25" for the date.
    """

    day = None

    if 'day' in df_request.parameters and df_request.parameters['day'] != '':
        day = df_request.parameters['day']
    elif (('dayoryear' in df_request.parameters) and
          (df_request.parameters['dayoryear'] != '') and
          (df_request.parameters['dayoryear'] < 50)):
        day = df_request.parameters['dayoryear']
    elif params is not None and 'currentday' in params:
        day = params['currentday']

    return day

def confirmation_year(df_request, params):
    """
    Year to confirm

    dayoryear hits this if > 50, e.g, "1985".
    """

    year = None

    if 'year' in df_request.parameters and df_request.parameters['year'] != '':
        year = df_request.parameters['year']
    elif (('dayoryear' in df_request.parameters) and
          (df_request.parameters['dayoryear'] != '') and
          (df_request.parameters['dayoryear'] >= 50)):
        year = df_request.parameters['dayoryear']
    elif params is not None and 'currentyear' in params:
        year = params['currentyear']

    return year

def confirm_dob_correct(df_request, df_response):
    """
    One-step correction for DOB.
    """

    # Get the parameters from the confirmdob context.

    for idx,name in enumerate(df_request.input_contexts['names']):
        if name == 'confirmdob':
            context = df_request.input_contexts['contexts'][idx]
            dob_context_params = context.get('parameters')

    # Get date params to confirm.
    # If they are not in the request parameters, get them from the context.

    confirm_month = confirmation_month(df_request, dob_context_params)
    confirm_day = confirmation_day(df_request, dob_context_params)
    confirm_year = confirmation_year(df_request, dob_context_params)

    # Confirmation text using extracted parameters
    df_response.output_text = (f"I heard {confirm_month} {int(confirm_day)} "
                               f"{int(confirm_year)}, is that right?")
