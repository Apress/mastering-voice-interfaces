"""
qaCatEat
"""


def can_eat(
        food,
        time=None):    # pylint: disable=unused-argument
    """
    Can we eat this?

    No time dependence yet
    """

    if food == 'brussels sprouts':
        return False

    return True

def qa_can_eat(df_request, df_response):
    """
    qaCanEat
    """

    parameters = df_request.parameters
    food_drink = parameters.get('foodDrink')

    # Save food in intent context

    if food_drink and not food_drink == '':
        df_response.intent_params['foodDrink'] = food_drink

    # TBD consult database for logic
    if can_eat(food_drink):
        df_response.output_text = f"You can eat {food_drink} today."
    else:
        df_response.output_text = f"Sorry, you cannot eat {food_drink} today!"
