# pylint: disable=R0912
"""
Default Fallback Intent
"""

import re

from ar_enter_dob import ar_enter_dob_escalating_nomatch
from spacy_parser import dependency_parse

def fallback(
        df_request,
        df_response):
    """
    fallback
    """

    if (df_request.error_information['numErrors'] >=
        df_request.error_information['maxErrors'] - 1):
        # If we've already seen too many errors, try another way.

        df_response.output_text = 'OK let\'s try this another way.'

    elif re.search('((say( that)? )?again|repeat( that)?)( please)?',
                 df_request.query_text):

        # repeat

        # Trigger the confirmYes event.
        df_response.event_to_trigger = 'repeat'
    else:
        # We didn't get a hit with regular expressions; try dependency parse.

        parse = dependency_parse(df_request.query_text)

        # Collect features from the dependency parse tree

        # Get the root node in the dependency parse tree
        root_verb_index = None
        root_verb_lemma = None
        for node in parse:
            if node.get('relation') == 'ROOT':
                root_verb_index = node.get('index')
                root_verb_lemma = node.get('lemma')

        # Get a dobj off the root node
        dobj_lemma = None
        for node in parse:
            if (node.get('relation') == 'dobj' and
                node.get('parent_index') == root_verb_index):
                dobj_lemma = node.get('lemma')

        if root_verb_lemma == 'do' and dobj_lemma == 'what':
            # "What should I do today?."

            # Trigger arTodaysTasks
            df_response.event_to_trigger = 'arTodaysTasks'
        else:
            # No dependency parse match

            # Look for a handler for nomatch 2 prompts
            nomatch2_dialog_functions = {
                'arenterdob': ar_enter_dob_escalating_nomatch}

            # Get the handler function based on the intent name.

            handler_function = None

            last_intent = df_request.most_recent_intent["name_all"]
            if last_intent == 'default_fallback_intent':
                # 2nd and above nomatch
                intent = df_request.most_recent_intent["name_non_fallback"]
                if intent:
                    handler_function = nomatch2_dialog_functions.get(intent)

            if handler_function:
                handler_function.__call__(df_request, df_response)
            else:
                # We didn't get an escalating handler; do we would have done
                df_response.output_text = df_request.fulfillment_text
