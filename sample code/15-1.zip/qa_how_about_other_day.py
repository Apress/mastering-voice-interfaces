"""
qaHowAboutOtherDay
"""

from qa_can_eat import can_eat

def qa_how_about_other_day(df_request, df_response):
    """
    qaHowAboutOtherDay
    """

    params = df_request.conversation_context_params
    food_drink = params.get('foodDrink')
    date = params.get('date')
    date_original = params.get('date.original')

    if food_drink and not food_drink == '':
        if can_eat(food_drink ,time=date):
            df_response.output_text = \
                f"You can eat {food_drink} {date_original}."
        else:
            df_response.output_text = \
                f"Sorry, you cannot eat {food_drink} {date_original}!"
    else:
        df_response.output_text = "I don\'t recall you asking about a food."
