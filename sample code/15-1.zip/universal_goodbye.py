"""
goodbye universal
"""


def universal_goodbye(
        df_request,     # pylint: disable=unused-argument
        df_response):
    """
    goodbye universal
    """

    df_response.output_text = 'Sorry, goodbye is not enabled here.'
