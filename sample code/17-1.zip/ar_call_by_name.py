# pylint: disable=R0912
# pylint: disable=R0915
"""
Call by name.
Here are the list of names:

Brent Jones
Brent Adams
Brent Barnes
Brent Carletti
Joe Jones
Kim Smith
Mary Poppins
"""

from confirmation_context import confirmation_context


def ar_call_by_name(df_request, df_response):
    """
    Call by name.
    """

    given_name = df_request.parameters.get('given-name')
    last_name = df_request.parameters.get('last-name')

    # Set first name and last name in intent context as parameters

    if given_name and not given_name == '':
        df_response.intent_params['given-name2'] = given_name

    if last_name and not last_name == '':
        df_response.intent_params['last-name2'] = last_name

    # Now the dialog logic
    if (given_name and not given_name == '' and
        last_name and not last_name == ''):

        # If the caller specified both the first name and the
        # last name (“Call Brent Jones”), we don’t need disambiguation,
        # just do that. This is the “do what you were going to do case,”
        # where the webhook does not modify what Dialogflow was going to
        # do anyway.

        if (given_name == df_request.repeat_information['recent_given_name'] and
            last_name == df_request.repeat_information['recent_last_name']):
            # Context-sensitive case where the same name was said in
            # a very short time window
            df_response.output_text = \
                ('I\'m sorry we seem to having trouble; '
                 'maybe that name is not in your dialer?')
        elif df_response.explicit_confirmation:
            df_response.output_text = \
                f"You want to call {given_name} {last_name}, right?"
            df_request.update_user_context(
                df_request.current_time,
                'requestedGivenName',
                given_name)
            df_request.update_user_context(
                df_request.current_time,
                'requestedLastName',
                last_name)
            df_response.output_contexts.append(
                confirmation_context(given_name,
                                     last_name))
        else:
            df_response.output_text = df_request.fulfillment_text
            df_request.update_name_history(
                df_request.current_time,
                given_name,
                last_name)
            df_response.end_conversation = True
            df_response.nva["do"] = True
    elif (given_name and not given_name == ''):

        # This section of the code is very specific to the name list
        # that we’ve set up. Later on we can make it more generic, and
        # hit databases and such.

        # If the caller only specified a first name

        if given_name == 'Brent':

            # If you need to disambiguate last name (e.g., “Call Brent”)

            # Personalization: look through the userContext. If all the
            # Brents are the same name and there are at least 3, assume
            # that one. The logic could be much more complex and look at
            # timestamps and have different rules, etc..., but this is a
            # simple example.

            name_dic = {}
            max_num = 0
            max_name = None
            user_context = df_request.user_context
            for timestamp in user_context:
                context_given_name = user_context[timestamp].get('givenName')
                context_last_name = user_context[timestamp].get('lastName')
                if (context_given_name and
                    context_given_name == given_name and
                    context_last_name and
                    df_request.current_time - float(timestamp) < 60):
                    
                    name_dic_last_name = name_dic.get(context_last_name)
                    if name_dic_last_name:
                        name_dic[context_last_name] = \
                            name_dic[context_last_name] + 1
                    else:
                        name_dic[context_last_name] = 1

                    if name_dic[context_last_name] > max_num:
                        max_num = name_dic[context_last_name]
                        max_name = context_last_name
            if len(name_dic) == 1 and max_num >= 3:
                # Personalization: Use the last name used previously.
                # It has to be the only one and used three or more times.
                # Assume explicit confirmation.

                df_response.output_text = \
                    f"You want to call {given_name} {max_name}, right?"
                df_response.output_contexts.append(
                    confirmation_context(given_name, max_name))
            else:
                # Change the response to ask the “Which Brent...” question.

                df_response.output_text = \
                    'Which Brent: Jones, Adams, Barnes, or Carletti?'

                # Add the output context callbyname.
                # Remember when you created arCallByNameDisambigLastName,
                # you added that as an input context, and might have
                # wondered where you set it? Here’s where that is.

                new_context = {
                    'name': ('projects/${PROJECT_ID}/agent/sessions'
                             '/${SESSION_ID}/contexts/callbyname'),
                    'lifespanCount': 5,
                    'parameters': {}
                }
                # The full context name is long; "callbyname" is only the
                # last part.

                # Add a parameter context-given-name to the callbyname
                # context. You can add parameters to contexts, and you’ll
                # see in a bit how useful that is.

                new_context['parameters']['context-given-name'] = given_name

                df_response.output_contexts.append(new_context)

        else:

            # If you don’t need to disambiguate, there’s only one name
            # (e.g., “Call Mary”), find the last name, and respond with
            # that. No need to ask. Remember, don’t disambiguate unless
            # you need to!

            if given_name == 'Kim':
                if df_response.explicit_confirmation:
                    df_response.output_text = \
                        "You want to call Kim Smith, right?"
                    df_request.update_user_context(
                        df_request.current_time,
                        'requestedGivenName',
                        'Kim')
                    df_request.update_user_context(
                        df_request.current_time,
                        'requestedLastName',
                        'Smith')
                    df_response.output_contexts.append(
                        confirmation_context("Kim", "Smith"))
                else:
                    df_response.output_text = 'OK, calling Kim Smith.'
                    df_request.update_name_history(
                        df_request.current_time,
                        'Kim',
                        'Smith')
                    df_response.end_conversation = True
                    df_response.nva["do"] = True
            elif given_name == 'Mary':
                if df_response.explicit_confirmation:
                    df_response.output_text = \
                        "You want to call Mary Poppins, right?"
                    df_request.update_user_context(
                        df_request.current_time,
                        'requestedGivenName',
                        'Mary')
                    df_request.update_user_context(
                        df_request.current_time,
                        'requestedLastName',
                        'Poppins')
                    df_response.output_contexts.append(
                        confirmation_context("Mary", "Poppins"))
                else:
                    df_response.output_text = 'OK, calling Mary Poppins.'
                    df_request.update_name_history(
                        df_request.current_time,
                        'Mary',
                        'Poppins')
                    df_response.end_conversation = True
                    df_response.nva["do"] = True
            else:

                # If you don’t have that first name (e.g., “Call Donald”),
                # play a response that says so.

                df_response.output_text = \
                    f"Sorry, there is no {given_name} in your list."
                df_response.end_conversation = True
