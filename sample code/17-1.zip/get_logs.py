# pylint: disable=R0912
# pylint: disable=R0914
# pylint: disable=R0915
"""
Get logs from Google Cloud Stackdriver.
"""

import json
import re

from google.cloud import logging


def main():
    """
    Get logs from Google Cloud Stackdriver
    """

    # Instantiates a client
    logging_client = logging.Client()

    logger = logging_client.logger('dialogflow_agent')

    df_request = None
    df_webhook_request = None

    date_time = ""
    session = ""
    recognized_text = ""
    recognized_intent = ""
    filled_parameters = {}
    task_tags = []

    print(("TIMESTAMP\tSESSION\tACTUAL TEXT\tRECOGNIZED TEXT\tACTUAL INTENT\t"
           "RECOGNIZED INTENT\tFILLED PARAMETERS\tAPPLICATION RESPONSE\tTASK"))

    havelog = False
    for entry in logger.list_entries():
        timestamp = entry.timestamp.isoformat()

        match = re.match('Dialogflow Request : (.*)$',entry.payload)
        if match:
            # Dump out last log if we had one

            if havelog:
                print((f"{date_time}\t{session}\t\t{recognized_text}\t\t"
                       f"{recognized_intent}\t{filled_parameters}\t"
                       f"{application_response}\t{json.dumps(task_tags)}"))

                df_request = None
                df_webhook_request = None

                date_time = ""
                session = ""
                recognized_text = ""
                recognized_intent = ""
                filled_parameters = {}
                task_tags = []

            # Onto the next log

            df_request = json.loads(match.group(1))

            # Date/time
            date_time = timestamp

            # Session
            try:
                session = df_request['session']
            except KeyError:
                pass

            # Recognized text
            try:
                json2 = json.loads(df_request['query_input'])
                recognized_text = json2['text']['textInputs'][0]['text']
            except KeyError:
                pass

        # Dialogflow fulfillment request (multi-line)

        pattern = re.compile(
            'Dialogflow fulfillment request : (.*)$',re.M | re.S
        )
        match = pattern.match(entry.payload)
        if match:
            df_webhook_request = json.loads(match.group(1))

            # Recognized intent
            try:
                recognized_intent = \
                    df_webhook_request['queryResult']['intent']['displayName']

                # Add any task tags here

                if recognized_intent == 'tcrProcedurePrep':
                    task = {}
                    task['name'] = 'ProcedurePrep'
                    task['tag'] = 'start'
                    task_tags.append(task)

                if recognized_intent == 'tcrProcedurePrepNext2':
                    task = {}
                    task['name'] = 'ProcedurePrep'
                    task['tag'] = 'end'
                    task_tags.append(task)

            except KeyError:
                pass

            # Filled parameters
            try:
                filled_parameters = \
                    json.dumps(df_webhook_request['queryResult']['parameters'])
            except KeyError:
                pass

        # Dialogflow response (multi-line)

        pattern = re.compile('Dialogflow Response : (.*)$',re.M | re.S)
        match = pattern.match(entry.payload)
        if match:
            havelog = True

            # Since the logged DF response is not real JSON,
            # we need to parse line by line (yuck)
            lastful = False
            for string in match.group(1).splitlines():
                if re.search(r'^\s*fulfillment {',string):
                    lastful = True

                match = re.search(r'\s*speech: "(.*)"',string)
                if lastful and match:
                    application_response = match.group(1)

    # Print out the final log

    if havelog:
        print((f"{date_time}\t{session}\t\t{recognized_text}\t\t"
               f"{recognized_intent}\t{filled_parameters}\t"
               f"{application_response}\t{json.dumps(task_tags)}"))

if __name__ == '__main__':
    main()
