"""
spaCy interface
"""

import spacy


def dependency_parse(text):
    """
    Get the spaCy dependency parse.

    Each node has:
    text
    dependency relation to parent (ROOT) if root
    parent node
    part of speech
    """

    # Load the spaCy models
    nlp = spacy.load('en_core_web_sm')

    # Run spaCy
    doc = nlp(text)

    # Initialize and collect the dependency parse
    parse = []

    for token in doc:
        node = {"text": token.text,
                "lemma": token.lemma_,
                "index": token.i,
                "relation": token.dep_,
                "parent_index": token.head.i,
                "pos": token.head.pos_}
        parse.append(node)

    return parse
