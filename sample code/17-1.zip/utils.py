"""
Utilities for use in the webhook
"""

def processed_intent_name(intent_name):
    """
    Lower case and _ instead of spaces.
    """

    return intent_name.lower().replace(' ', '_')

def is_skippable_universal(intent_name):
    """
    Is this a skippable universal?
    """

    return intent_name in ['cancel', 'continue', 'goBack', 'goodbye', 'help',
                           'pause', 'repeat', 'startOver', 'transfer',
                           'default_fallback_intent']

def same_conversation(
        timestamp):     # pylint: disable=unused-argument
    """
    Is this the same conversation?
    Right now, default to true
    """

    return True

def upcoming_events(
        timestamp):     # pylint: disable=unused-argument
    """
    Returns proactive list of upcoming events
    """

    return []
