"""
The WebhookResponse class contains the information to pass back to Dialogflow.
"""

import json

class WebhookResponse():
    """
    The WebhookResponse class contains the information for the
    Dialogflow webhook response.
    """

    def __init__(self):
        """
        Initialize the variables that will drive the response.
        """

        self.output_contexts = []
        self.output_text = ''

        # The output response dictionary
        self.respdic = {}

    def response_string(self):
        """
        Return the JSON response string.
        """

        return json.dumps(self.response_json())

    def response_json(self):
        """
        Return the JSON response dictionary.
        """

        # Set the response text.
        self.respdic['fulfillment_text'] = self.output_text

        # Set the output contexts if needed.
        if len(self.output_contexts) > 0:
            self.respdic['outputContexts'] = self.output_contexts

        # Return the webhook response.
        return self.respdic
