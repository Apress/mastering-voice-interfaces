"""
Dialogflow intent for when we need to disambiguate with last name.
"""

import re

def ar_call_by_name_disambig_last_name(df_request, df_response):
    """
    Get the first name from the previous arCallByName intent, from the
    context-given-name parameter that was set in the callbyname context
    (we told you that would be useful). The caller might have said
    the first name in the response to “Which Brent...”, e.g. “Brent
    Jones” instead of just “Jones,” but you can’t be sure, so you need
    to go get it.
    """

    context_name = ''
    given_name = None
    last_name = df_request.parameters.get('last-name')

    for context in df_request.input_contexts:
        fullname = context.get('name')
        parameters = context.get('parameters')
        if parameters:
            given_name = parameters.get('context-given-name')

        if fullname:
            # fullname is a very long string; we only need the last part
            # of it, after the final /.
            match = re.search('/([^/]*)$', fullname)
            if (match and match.group(1) == 'callbyname') and given_name:
                context_name = parameters.get('context-given-name')

    if (last_name in ['Jones', 'Adams', 'Barnes', 'Carletti']):

        # If the last name supplied in this disambiguation step is valid,
        # then play the “OK, calling...” response, and you’re done.

        df_response.output_text = f"OK, calling {context_name} {last_name}."
        df_response.end_conversation = True
        df_response.do_pre_nva = True
    else:

        # If the last name is not valid, say so

        df_response.output_text = \
            f"Sorry, {context_name} {last_name} is not in your list."
        df_response.end_conversation = True
