"""
main.py is the high-level module implementing the Dialogflow webhook.

The interface between Dialogflow and the webhook is documented at:
https://cloud.google.com/dialogflow/es/docs/fulfillment-webhook
"""

from flask import Flask
from flask import request

from webhook_request import WebhookRequest
from webhook_response import WebhookResponse
from ar_call_by_name import ar_call_by_name
from ar_call_by_name_disambig_last_name\
    import ar_call_by_name_disambig_last_name

app = Flask(__name__)


@app.route('/', methods=['POST'])
def main():
    """
    Remember the Webhook Request?
    You first need to pull out the information from the request to make
    it available to the code later.
    """

    # The object for the Dialogflow request
    df_request = WebhookRequest()

    # The object for the Dialogflow response
    df_response = WebhookResponse()

    # Load the WebhookRequest object from the request dictionary
    # request and request.data are things we know are there from the Flask
    # web service toolkit.

    df_request.load_from_string(request.data)

    #
    # Now comes the actual dialog logic.
    # Each Dialogflow intent is processed by it's own function
    # in it's own file.
    #

    if df_request.intent_display_name == 'arCallByName':
        ar_call_by_name(df_request, df_response)
    elif df_request.intent_display_name == 'arCallByNameDisambigLastName':
        ar_call_by_name_disambig_last_name(df_request, df_response)
    else:
        # If the intent is anything else, just return back what Dialogflow
        # was going to do anyway; don’t modify the behavior. Use the given
        # response from Dialogflow

        df_response.output_text = df_request.fulfillment_text

    # You’re not quite done yet.
    # Return the response back to Dialogflow.

    return df_response.response_string()


if __name__ == '__main__':
    # This is used when running locally only. When deploying to Google App
    # Engine, a webserver process such as Gunicorn will serve the app. This
    # can be configured by adding an `entrypoint` to app.yaml.
    app.run(host='127.0.0.1', port=8080, debug=True)
