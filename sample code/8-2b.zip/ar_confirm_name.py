"""
Dialogflow intent for when are explicitly confirming a name to be called.
"""


def ar_confirm_name(df_request, df_response):
    """
    Result of an explicit name confirmation
    """

    if 'confirm' in df_request.parameters:
        if df_request.parameters['confirm'] == 'yes':
            # The caller has confirmed the name. Play it.

            df_response.output_text = 'OK, calling.'
            df_response.end_conversation = True
            df_response.do_pre_nva = True

        elif df_request.parameters['confirm'] == 'no':
            # Negative confirmation

            df_response.output_text = 'Sorry.'
            df_response.end_conversation = True
