"""
main.py is the high-level module implementing the Dialogflow webhook.

The interface between Dialogflow and the webhook is documented at:
https://cloud.google.com/dialogflow/es/docs/fulfillment-webhook
"""

from flask import Flask
from flask import request

from webhook_request import WebhookRequest
from webhook_response import WebhookResponse
from new_context import new_context

# Here are the handlers for the Dialogflow intents.
from ar_call_by_name import ar_call_by_name
from ar_call_by_name_disambig_last_name\
    import ar_call_by_name_disambig_last_name
from ar_confirm_name import ar_confirm_name
from universal_cancel import universal_cancel
from universal_continue import universal_continue
from universal_go_back import universal_go_back
from universal_goodbye import universal_goodbye
from universal_help import universal_help
from universal_main_menu import universal_main_menu
from universal_pause import universal_pause
from universal_repeat import universal_repeat
from universal_start_over import universal_start_over
from universal_transfer import universal_transfer

app = Flask(__name__)


@app.route('/', methods=['POST'])
def main():
    """
    Remember the Webhook Request?
    You first need to pull out the information from the request to make
    it available to the code later.
    """

    # The object for the Dialogflow request
    df_request = WebhookRequest()

    # The object for the Dialogflow response
    df_response = WebhookResponse()

    # Load the WebhookRequest object from the request dictionary
    # request and request.data are things we know are there from the Flask
    # web service toolkit.

    df_request.load_from_string(request.data)

    #
    # Now comes the actual dialog logic.
    # Each Dialogflow intent is processed by it's own function
    # in it's own file.
    #

    # We're handling so many intents now that there's a better way than
    # if statements.

    # Here is a dictionary that maps the intent name to the handler function.
    # The value in the dictionary is the actual handler function for the intent.

    dialog_functions = {
        'arCallByName': ar_call_by_name,
        'arCollectName': ar_call_by_name,
        'arCallByNameDisambigLastName': ar_call_by_name_disambig_last_name,
        'arConfirmName': ar_confirm_name,
        'cancel': universal_cancel,
        'continue': universal_continue,
        'goBack': universal_go_back,
        'goodbye': universal_goodbye,
        'help': universal_help,
        'mainMenu': universal_main_menu,
        'pause': universal_pause,
        'repeat': universal_repeat,
        'startOver': universal_start_over,
        'transfer': universal_transfer}

    # Get the handler function based on the intent name.
    handler_function = dialog_functions.get(df_request.intent_display_name)

    if handler_function:
        # The core.
        # If we found a handler function, call it with the request and response.

        # This is how you call a function without knowing ahead of time
        # what function you're calling.

        # The arguments are always the same even if the handler function
        # doesn't use them, so sometimes we'll be turning off pylint warnings.

        handler_function.__call__(df_request, df_response)
    else:
        # If the intent is anything else, just return back what Dialogflow
        # was going to do anyway; don’t modify the behavior. Use the given
        # response from Dialogflow

        df_response.output_text = df_request.fulfillment_text

    # Add an output context with the intent,
    # so we can determine the last intent for universals.

    output_intent_name = df_request.intent_display_name.lower().replace(' ','_')
    df_response.output_contexts.append(
        new_context(f"intent_{output_intent_name}"))

    # You’re not quite done yet.
    # Return the response back to Dialogflow.

    return df_response.response_string()


if __name__ == '__main__':
    # This is used when running locally only. When deploying to Google App
    # Engine, a webserver process such as Gunicorn will serve the app. This
    # can be configured by adding an `entrypoint` to app.yaml.
    app.run(host='127.0.0.1', port=8080, debug=True)
