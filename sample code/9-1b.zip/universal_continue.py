"""
continue universal
"""


def universal_continue(
        df_request,     # pylint: disable=unused-argument
        df_response):
    """
    continue universal
    """

    df_response.output_text = 'Sorry, continue is not enabled here.'
