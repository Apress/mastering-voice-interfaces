"""
main menu universal
"""


def universal_main_menu(
        df_request,     # pylint: disable=unused-argument
        df_response):
    """
    main menu universal
    """

    df_response.output_text = \
        "You're back at the main menu. What would you like to do?"
