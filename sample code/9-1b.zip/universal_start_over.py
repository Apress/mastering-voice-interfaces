"""
start over universal
"""


def universal_start_over(
        df_request,     # pylint: disable=unused-argument
        df_response):
    """
    start over universal
    """

    df_response.output_text = 'Sorry, starting over is not enabled here.'
