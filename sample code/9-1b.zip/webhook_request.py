"""
The webhook_request module contains the WebhookRequest class
for the Dialogflow request.
"""

import json
import re

from set_most_recent_intent import set_most_recent_intent

class WebhookRequest():
    """
    The WebhookRequest class contains the information from the
    Dialogflow webhook request.
    """

    def __init__(self):
        """
        Initialize the WebhookRequest with variables that could be loaded.
        """

        # Here is the various information pulled out of the webhook request.

        # The intent that was triggered
        self.intent_display_name = ''

        # How Dialogflow was going to respond
        self.fulfillment_text = ''

        # The contexts that were going to be set
        self.input_contexts = []
        self.input_context_names = []

        # Parameters that were supplied, either from the user speech/text or
        # from contexts.
        self.parameters = []

        # The Dialogflow session
        self.session = None

        # The most recent intent.
        # Need that for notion of dialog state for universals.
        self.most_recent_intent = {"name": None, "time": 0}


    def load_from_json(self, request_json):
        """
        Load the WebhookRequest from a JSON dictionary.
        """

        # The unique request/response and session identifiers
        self.session = request_json['session']

        # The full session name is a long string; here we’re just pulling out
        # the tail, or the part after the last /.

        match = re.search('/([^/]*)$', self.session)
        if match:
            self.session = match.group(1)

        if 'queryResult' in request_json:
            query_result = request_json['queryResult']
            if 'intent' in query_result:
                self.intent_display_name = query_result['intent']['displayName']
            if 'fulfillmentText' in query_result:
                self.fulfillment_text = query_result['fulfillmentText']
            # These are called ‘outputContexts’ but they really are the inputs
            # in the Dialogflow request.
            if 'outputContexts' in query_result:
                self.input_contexts = query_result['outputContexts']
                for dic in self.input_contexts:
                    if 'name' in dic:
                        fullname = dic['name']
                        # Same as session; the full context name is long, and
                        # we’re using regular expressions to pull out only the
                        # part after the last /.
                        match = re.search('/([^/]*)$', fullname)
                        if match:
                            self.input_context_names.append(match.group(1))

                            # If this is the most recent intent, set that.
                            set_most_recent_intent(self, match.group(1), dic)
            if 'parameters' in query_result:
                self.parameters = query_result['parameters']

    def load_from_string(self, string):
        """
        Load from string, which we get from the Dialogflow request.
        """

        self.load_from_json(json.loads(string))
