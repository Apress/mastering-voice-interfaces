"""
The WebhookResponse class contains the information to pass back to Dialogflow.
"""

import json

class WebhookResponse():
    """
    The WebhookResponse class contains the information for the
    Dialogflow webhook response.
    """

    def __init__(self):
        """
        Initialize the variables that will drive the response.
        """

        self.output_contexts = []
        self.output_text = ''

        # Do we end the conversation?
        self.end_conversation = False

        # Do we play NVA before the output prompt?
        self.do_pre_nva = False

        # Are we doing explicit confirmation?
        self.explicit_confirmation = True

        # The output response dictionary
        self.respdic = {}

    def response_string(self):
        """
        Return the JSON response string.
        """

        return json.dumps(self.response_json())

    def response_json(self):
        """
        Return the JSON response dictionary.
        """

        # Set the response text.
        self.respdic['fulfillment_text'] = self.output_text

        # Did we add the Actions on Google payload?
        add_payload = False

        # End the conversation if that's relevant.
        if self.end_conversation:
            self.respdic['payload'] = {}
            self.respdic['payload']['google'] = {}
            self.respdic['payload']['google']['expectUserResponse'] = False
            add_payload = True

        # If we are doing pre-NVA, add the payload for Actions on Google.
        if self.do_pre_nva:
            if not add_payload:
                self.respdic['payload'] = {}
                self.respdic['payload']['google'] = {}
            self.respdic['payload']['google']['richResponse'] = {}
            self.respdic['payload']['google']['richResponse']['items'] = []
            tmpdic = {}
            tmpdic['simpleResponse'] = {}
            tmpdic['simpleResponse']['textToSpeech'] = \
                ("<speak><audio src=\"https://actions.google.com/sounds/v1/"
                 "cartoon/cartoon_metal_thunk.ogg\" clipBegin=\"1.5s\" "
                 f"clipEnd=\"3s\">DING</audio>{self.output_text}</speak>")
            self.respdic['payload']['google']['richResponse']['items']\
                .append(tmpdic)

        # Set the output contexts if needed.
        if len(self.output_contexts) > 0:
            self.respdic['outputContexts'] = self.output_contexts

        # Return the webhook response.
        return self.respdic
