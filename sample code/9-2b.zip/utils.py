"""
Utilities for use in the webhook
"""

def processed_intent_name(intent_name):
    """
    Lower case and _ instead of spaces.
    """

    return intent_name.lower().replace(' ', '_')


def is_skippable_universal(intent_name):
    """
    Is this a skippable universal?
    """

    return intent_name in ['cancel', 'continue', 'goBack', 'goodbye', 'help',
                           'pause', 'repeat', 'startOver', 'transfer']
