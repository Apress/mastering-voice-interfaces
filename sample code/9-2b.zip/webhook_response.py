"""
The WebhookResponse class contains the information to pass back to Dialogflow.
"""

import json
import random
import re

class WebhookResponse():
    """
    The WebhookResponse class contains the information for the
    Dialogflow webhook response.
    """

    def __init__(self):
        """
        Initialize the variables that will drive the response.
        """

        self.output_contexts = []
        self.output_text = ''

        # Do we end the conversation?
        self.end_conversation = False

        # NVA
        self.nva = {"do": False, "src": None, "begin": None, "end": None}

        # Are we doing explicit confirmation?
        self.explicit_confirmation = True

        # The output response dictionary
        self.respdic = {}

    def response_string(self):
        """
        Return the JSON response string.
        """

        return json.dumps(self.response_json())

    def response_json(self):
        """
        Return the JSON response dictionary.
        """

        # Possibly replace prompt intro with a randomized variant.

        if (re.search('^OK,',self.output_text) or
            re.search('^OK.',self.output_text) or
            re.search('^All right,',self.output_text) or
            re.search('^All right.',self.output_text)):

            random_intro = random.choice(['OK','All right',''])

            if random_intro == '':
                self.output_text = re.sub('^OK,',
                                          '',
                                          self.output_text)
                self.output_text = re.sub('^OK.',
                                          '',
                                          self.output_text)
                self.output_text = re.sub('^All right,',
                                          '',
                                          self.output_text)
                self.output_text = re.sub('^All right.',
                                          '',
                                          self.output_text)
            else:
                self.output_text = re.sub('^OK,',
                                          f"{random_intro},",
                                          self.output_text)
                self.output_text = re.sub('^OK.',
                                          f"{random_intro}.",
                                          self.output_text)
                self.output_text = re.sub('^All right,',
                                          f"{random_intro},",
                                          self.output_text)
                self.output_text = re.sub('^All right.',
                                          f"{random_intro}.",
                                          self.output_text)

        # Set the response text.
        self.respdic['fulfillment_text'] = self.output_text

        # Did we add the Actions on Google payload?
        add_payload = False

        # End the conversation if that's relevant.
        if self.end_conversation:
            self.respdic['payload'] = {}
            self.respdic['payload']['google'] = {}
            self.respdic['payload']['google']['expectUserResponse'] = False
            add_payload = True

        # If we are doing pre-NVA, add the payload for Actions on Google.
        if self.nva.get("do"):
            # Select our NVA src, begin, and end if it hasn't been specified
            if self.nva.get("src") is None:
                self.nva.update({
                    "src": ("https://actions.google.com/sounds/v1/"
                            "cartoon/cartoon_metal_thunk.ogg"),
                    "begin": "1.s",
                    "end": "3s"})

            if not add_payload:
                self.respdic['payload'] = {}
                self.respdic['payload']['google'] = {}
            self.respdic['payload']['google']['richResponse'] = {}
            self.respdic['payload']['google']['richResponse']['items'] = []
            tmpdic = {}
            tmpdic['simpleResponse'] = {}

            # Put together the SSML
            ssml = f"<speak><audio src=\"{self.nva.get('src')}\""
            if self.nva.get("begin") is not None:
                ssml = f"{ssml} clipBegin=\"{self.nva.get('begin')}\""
            if self.nva.get("end") is not None:
                ssml = f"{ssml} clipEnd=\"{self.nva.get('end')}\""
            ssml = f"{ssml}>DING</audio>{self.output_text}</speak>"
            print(f"'SSML: {ssml}")
            tmpdic['simpleResponse']['textToSpeech'] = ssml
            self.respdic['payload']['google']['richResponse']['items']\
                .append(tmpdic)

        # Set the output contexts if needed.
        if len(self.output_contexts) > 0:
            self.respdic['outputContexts'] = self.output_contexts

        # Return the webhook response.
        return self.respdic
